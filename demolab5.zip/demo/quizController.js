const quizContainer = document.getElementById("quiz-container");
const nextButton = document.getElementById("next-button");

function loadQuestions() {
    fetch("/quiz/questions")  
        .then(response => response.json())  
        .then(data => {
            
            if (data.length > 0) {
                
                loadQuestion(data[0]);
            } else {
                quizContainer.innerHTML = "<p>No questions available.</p>";
                nextButton.disabled = true;
            }
        })
        .catch(error => {
            console.error("Error fetching quiz questions:", error);
        });
}

function loadQuestion(question) {
    quizContainer.innerHTML = `
        <h3>${question.question}</h3>
        <ul>
            <li>${question.options[0]}</li>
            <li>${question.options[1]}</li>
            <li>${question.options[2]}</li>
        </ul>
    `;
}

nextButton.addEventListener("click", loadQuestions);

loadQuestions();
