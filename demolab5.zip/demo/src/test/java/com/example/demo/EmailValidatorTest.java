package com.example.demo.records;

import com.example.demo.EmailValidationResult;
import com.example.demo.EmailController;
import com.example.demo.EmailValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

public class EmailValidatorTest {
    private EmailValidator emailValidator;

    @BeforeEach
    public void setup() {
        Set<String> validEmails = new HashSet<>();
        validEmails.add("example@gmail.com");
        validEmails.add("test@yahoo.com");
        validEmails.add("user@example.com");
        emailValidator = new EmailValidator(validEmails);
    }

    @Test
    public void testValidEmail() {
        EmailValidationResult result = emailValidator.validate("example@gmail.com");
        assertTrue(result.isValid());
        assertEquals("Valid Email", result.errorMessage());
    }

    @Test
    public void testInvalidEmailFormat() {
        EmailValidationResult result = emailValidator.validate("invalid-email");
        assertFalse(result.isValid());
        assertEquals("Email not found or invalid format", result.errorMessage());
    }

    @Test
    public void testInvalidEmail() {
        EmailValidationResult result = emailValidator.validate("example@yahoo.com");
        assertFalse(result.isValid());
        assertEquals("Email not found or invalid format", result.errorMessage());
    }
}
