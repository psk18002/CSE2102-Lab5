package com.example.demo;

import com.example.demo.QuizService;
import com.example.demo.QuizController;
import com.example.demo.QuizQuestion;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class QuizServiceTest {
    @Test
    public void testGetQuestions() {
        QuizService quizService = new QuizService();
        List<QuizQuestion> questions = quizService.getQuestions();

        assertNotNull(questions);
        assertTrue(questions.size() > 0);
    }
}
