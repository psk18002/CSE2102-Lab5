package com.example.demo;

import com.example.demo.PasswordController;
import com.example.demo.PasswordValidationResult;
import com.example.demo.PasswordValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Set;
import java.util.HashSet;

import static org.junit.jupiter.api.Assertions.*;

public class PasswordValidatorTest {
    private PasswordValidator passwordValidator;

    @BeforeEach
    public void setup() {
        Set<String> validPasswords = new HashSet<>();
        validPasswords.add("StrongPassword123");
        passwordValidator = new PasswordValidator(validPasswords);
    }

    @Test
    public void testValidPassword() {
        PasswordValidationResult result = passwordValidator.validate("StrongPassword123");
        assertTrue(result.isValid());
        assertEquals("Valid Password", result.errorMessage());
    }

    @Test
    public void testInvalidPassword() {
        PasswordValidationResult result = passwordValidator.validate("WeakPass");
        assertFalse(result.isValid());
        assertEquals("Password not found", result.errorMessage());
    }
}
