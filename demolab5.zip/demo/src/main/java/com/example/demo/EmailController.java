package com.example.demo;

import com.example.demo.EmailValidationResult;
import com.example.demo.EmailValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/email")
public class EmailController {

    @Autowired
    private EmailValidator emailValidator;

    @GetMapping("/check")
    public ResponseEntity<EmailValidationResult> checkEmail(@RequestParam String email) {
        EmailValidationResult result = emailValidator.validate(email);
        if (result.isValid()) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.badRequest().body(result);
        }
    }
}