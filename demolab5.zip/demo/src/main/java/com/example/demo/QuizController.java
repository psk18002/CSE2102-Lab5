package com.example.demo;


import com.example.demo.QuizQuestion;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.MediaType;
import java.util.List;

@RestController
public class QuizController {
    private final QuizService quizService;

    public QuizController(QuizService quizService) {
        this.quizService = quizService;
    }

    @GetMapping(value = "/quiz/questions", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<QuizQuestion> getQuizQuestions() {
        return quizService.getQuestions();
    }
}
