package com.example.demo;

public record PasswordValidationResult(boolean isValid, String errorMessage) { }