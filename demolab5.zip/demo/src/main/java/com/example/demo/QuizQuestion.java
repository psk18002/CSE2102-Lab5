package com.example.demo;

import java.util.List;

public record QuizQuestion(String question, List<String> options, int correctOption) { }