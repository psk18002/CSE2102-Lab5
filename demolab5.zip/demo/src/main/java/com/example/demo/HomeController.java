package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
public class HomeController {
    private final PasswordValidator passwordValidator;

    @Autowired
    public HomeController(PasswordValidator passwordValidator) {
        this.passwordValidator = passwordValidator;
    }

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/logincreate")
    public String logincreate() {
        return "logincreate";
    }

    @GetMapping("/usr")
    public String usrProfile() {
        return "usrProfile";
    }

    @GetMapping("/qna")
        public String qna() {
            return "qna";
    }

    @PostMapping
    public String login(@RequestBody String password) {
        PasswordValidationResult result = passwordValidator.validate(password);

        if (result.isValid()) {
            return "loginSuccess"; 
        } else {
            return "loginError"; 
        }
    }
}