package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class HomeController {
    private final PasswordValidator passwordValidator;
    private final EmailValidator emailValidator;

    @Autowired
    public HomeController(PasswordValidator passwordValidator, EmailValidator emailValidator) {
        this.passwordValidator = passwordValidator;
        this.emailValidator = emailValidator;
    }

    @GetMapping("/")
    public String home() {
        return "home";
    }

    @GetMapping("/logincreate")
    public String logincreate(Model model) {
        model.addAttribute("accountCredentials", new AccountCredentials());
        return "logincreate";
    }

    @GetMapping("/usr")
    public String usrProfile() {
        return "usrProfile";
    }

    @GetMapping("/qna")
        public String qna() {
            return "qna";
    }

    @PostMapping("/logincreate")
    public String processForm(@ModelAttribute("accountCredentials") AccountCredentials accountCredentials, Model model) {
        EmailValidationResult emailValidationResult = emailValidator.validate(accountCredentials.getEmail());
        PasswordValidationResult passwordValidationResult = passwordValidator.validate(accountCredentials.getPassword());
        System.out.printf("%s\n", accountCredentials.getEmail());
        System.out.print("%s\n", accountCredentials.getPassword());        
        //System.out.print(emailValidationResult);
        //System.out.print(passwordValidationResult);

        if (emailValidationResult.isValid() && passwordValidationResult.isValid()) {
            model.addAttribute("emailSuccess", emailValidationResult.errorMessage());
            model.addAttribute("passwordSuccess", passwordValidationResult.errorMessage());
            return "loginSuccess";
        } else {
            model.addAttribute("emailFailure", emailValidationResult.errorMessage());
            model.addAttribute("passwordFailure", passwordValidationResult.errorMessage());
            return "loginError";
        }
    }
}
