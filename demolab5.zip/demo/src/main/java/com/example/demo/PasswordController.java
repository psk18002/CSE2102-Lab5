package com.example.demo;

import com.example.demo.PasswordValidationResult;
import com.example.demo.PasswordValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.Set;


@RestController
@RequestMapping("/password")
public class PasswordController {
    private final PasswordValidator passwordValidator;

    @Autowired
    public PasswordController() {
        Set<String> validPasswords = Set.of("YetAnotherValidPassword", "AnotherValidPassword", "StrongPassword123", "Password123", "SecurePass");
        passwordValidator = new PasswordValidator(validPasswords);
    }

    @GetMapping("/check")
    public ResponseEntity<PasswordValidationResult> checkPassword(@RequestParam String password) {
        PasswordValidationResult result = passwordValidator.validate(password);
        if (result.isValid()) {
            return ResponseEntity.ok(result);
        } else {
            return ResponseEntity.badRequest().body(result);
        }
    }
}