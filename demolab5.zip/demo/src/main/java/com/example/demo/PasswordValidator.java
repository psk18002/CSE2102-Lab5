package com.example.demo;

import com.example.demo.PasswordValidationResult;
import org.springframework.stereotype.Component;
import java.util.Set;
import java.util.HashSet;

@Component
public class PasswordValidator {
    public Set<String> validPasswords;
    
    public PasswordValidator(Set<String> validPasswords) {
        this.validPasswords = new HashSet<>(Set.of("YetAnotherValidPassword"));
    }

    public PasswordValidationResult validate(String password) {
        if (validPasswords.contains(password)) {
            return new PasswordValidationResult(true, "Valid Password");
        }

        return new PasswordValidationResult(false, "Password not found");
    }
}