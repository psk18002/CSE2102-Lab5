package com.example.demo;

import com.example.demo.EmailValidationResult;
import org.springframework.stereotype.Component;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

@Component
public class EmailValidator {
    private Set<String> validEmails;
    private Pattern emailPattern;

    public EmailValidator(Set<String> validEmails) {
        this.validEmails = validEmails;
        this.emailPattern = Pattern.compile("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$");
    }

    public EmailValidationResult validate(String email) {
        if (validEmails.contains(email) && emailPattern.matcher(email).matches()) {
            return new EmailValidationResult(true, "Valid Email");
        }

        return new EmailValidationResult(false, "Email not found or invalid format");
    }
}
