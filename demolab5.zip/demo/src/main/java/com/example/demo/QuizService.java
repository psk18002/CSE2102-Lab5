package com.example.demo;

import org.springframework.stereotype.Service;
import com.example.demo.QuizQuestion;
import java.util.List;
import java.util.ArrayList;

@Service
public class QuizService {
    private List<QuizQuestion> quizQuestions;

    public QuizService() {
        quizQuestions = new ArrayList<>();
        quizQuestions.add(new QuizQuestion("What is 2 + 2?", List.of("3", "4", "5"), 1));
        quizQuestions.add(new QuizQuestion("Which planet is known as the Red Planet?", List.of("Earth", "Mars", "Venus"), 1));
        quizQuestions.add(new QuizQuestion("What is the capital of France?", List.of("London", "Paris", "Berlin"), 1));
    }

    public List<QuizQuestion> getQuestions() {
        return quizQuestions;
    }
}
