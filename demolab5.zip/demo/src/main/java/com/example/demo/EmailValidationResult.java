package com.example.demo;

public record EmailValidationResult(boolean isValid, String errorMessage) { }